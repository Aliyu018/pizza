﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.Image = WindowsFormsApp2.Properties.Resources.Americanna;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.Image=WindowsFormsApp2.Properties.Resources.Italiana;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 F2=new Form2();
            if (radioButton1.Checked)
                F2.PizzaType = radioButton1.Text;
            else
                F2.PizzaType = radioButton2.Text;
            F2.Show();
        }
    }
}
