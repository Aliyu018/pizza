﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        public string PizzaType;
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 F3=new Form3();
            F3.label1.Text += PizzaType;
            if (checkBox1.Checked)
                F3.label2.Text += checkBox1.Text+" , ";
            if (checkBox2.Checked)
                F3.label2.Text += checkBox2.Text + " , ";
            if (checkBox3.Checked)
                F3.label2.Text += checkBox3.Text + " , ";
            if (checkBox4.Checked)
                F3.label2.Text += checkBox4.Text + " , ";
            if (checkBox5.Checked)
                F3.label2.Text += checkBox5.Text + " , ";
            if (checkBox6.Checked)
                F3.label2.Text += checkBox6.Text + " , ";

            F3.Show();
        }
    }
}
